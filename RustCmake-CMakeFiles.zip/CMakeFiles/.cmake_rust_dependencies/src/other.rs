/// Test function
pub fn test()
{
	println!("Hello");
}
