//! Test library compiled using CMake.

#[crate_id="test"];
#[crate_type="lib"];

pub mod other;
